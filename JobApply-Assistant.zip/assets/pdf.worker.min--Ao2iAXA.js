var e=`/assets/pdf.worker.min-CjEcRF4W.mjs`;export{e as default};
//# sourceMappingURL=pdf.worker.min--Ao2iAXA.js.map